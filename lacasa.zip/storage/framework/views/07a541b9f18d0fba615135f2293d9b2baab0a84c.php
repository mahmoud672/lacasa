<?php $__env->startSection('title', 'Dashboard'); ?>
<!-- Drop Your Customized Style Here -->
<?php $__env->startSection('customizedStyle'); ?>
<?php $__env->stopSection(); ?>
<!-- Drop Your Customized Scripts Here -->
<?php $__env->startSection('customizedScript'); ?>
<?php $__env->stopSection(); ?>
<!-- Start of content section -->
<?php $__env->startSection('content'); ?>


    <!-- Main content -->
    <section class="content container-fluid">
        <div class="rgs-wrapper">


            <!-- start stats section -->
            <div class="stats-section">
                <div class="section-heading">
                    <i class="ion-stats-bars"></i>
                    <p>
                        Statistics
                    </p>
                </div>
                <div class="section-body">
                    <ul>
                        <li>
                            <a href="#">
                                <div class="li-left">
                                    <div class="counter">
                                        <p>
                                            <?php echo e($services); ?>

                                        </p>
                                    </div>
                                    <div class="title">
                                        <p>
                                            Services
                                        </p>
                                    </div>
                                </div>
                                <div class="li-right">
                                    <i class="ion ion-document-text"></i>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="li-left">
                                    <div class="counter">
                                        <p>
                                            <?php echo e($articles); ?>

                                        </p>
                                    </div>
                                    <div class="title">
                                        <p>
                                           Articles
                                        </p>
                                    </div>
                                </div>
                                <div class="li-right">
                                    <i class="ion ion-edit"></i>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="li-left">
                                    <div class="counter">
                                        <p>
                                            <?php echo e($images); ?>

                                        </p>
                                    </div>
                                    <div class="title">
                                        <p>
                                            Images
                                        </p>
                                    </div>
                                </div>
                                <div class="li-right">
                                    <i class="ion-ios-albums-outline"></i>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="li-left">
                                    <div class="counter">
                                        <p>
                                            <?php echo e($messages); ?>

                                        </p>
                                    </div>
                                    <div class="title">
                                        <p>
                                           Messages
                                        </p>
                                    </div>
                                </div>
                                <div class="li-right">
                                    <i class="ion-ios-email-outline"></i>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- end stats section -->


            <!-- start shortcuts section -->
            <div class="shortcuts-section">
                <div class="section-heading">
                    <i class="ion-shuffle"></i>
                    <p>
                        Shortcuts
                    </p>
                </div>
                <div class="section-body">
                    <ul>
                        <li>
                            <a href="<?php echo e(adminUrl('contact/edit')); ?>">
                                <div class="li-img">
                                    <img src="<?php echo e(asset('dashboard/img/shortcuts/phone-call.png')); ?>" alt="img">
                                </div>
                                <div class="li-title">
                                    <p>
                                        Edit Contact Info
                                    </p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(adminUrl('service/create')); ?>">
                                <div class="li-img">
                                    <img src="<?php echo e(asset('dashboard/img/welcome/setting.png')); ?>" alt="img">
                                </div>
                                <div class="li-title">
                                    <p>
                                        Add Service
                                    </p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(adminUrl('video/create')); ?>">
                                <div class="li-img">
                                    <img src="<?php echo e(asset('dashboard/img/welcome/video.png')); ?>" alt="img">
                                </div>
                                <div class="li-title">
                                    <p>
                                        Add Video
                                    </p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(adminUrl('slider/create')); ?>">
                                <div class="li-img">
                                    <img src="<?php echo e(asset('dashboard/img/welcome/slider.png')); ?>" alt="img">
                                </div>
                                <div class="li-title">
                                    <p>
                                        Add Slide
                                    </p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(adminUrl('gallery/create')); ?>">
                                <div class="li-img">
                                    <img src="<?php echo e(asset('dashboard/img/welcome/upload.png')); ?>" alt="img">
                                </div>
                                <div class="li-title">
                                    <p>
                                        Add Image to Gallery
                                    </p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(adminUrl('setting/edit')); ?>">
                                <div class="li-img">
                                    <img src="<?php echo e(asset('dashboard/img/welcome/settings.png')); ?>" alt="img">
                                </div>
                                <div class="li-title">
                                    <p>
                                       Edit Setting
                                    </p>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- end shortcuts section -->



            

            <!-- start charts section -->


            

            <!-- end charts section -->

          

        </div>
    </section>
    <!-- /.content -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/dashboard/welcome.blade.php ENDPATH**/ ?>