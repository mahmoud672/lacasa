<?php if(count($errors) > 0): ?>
    <div class="w-100">
        <div class="alert alert-danger" style="background-color: #f66e84">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php endif; ?>


<?php if(Session::has('create')): ?>
    <div class="alert alert-success alert-block" >
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e(session('create')); ?></strong>
    </div>
<?php endif; ?>

<?php if(Session::has('update')): ?>
    <div class="alert alert-success alert-block" >
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e(session('update')); ?></strong>
    </div>
<?php endif; ?>


<?php if(Session::has('delete')): ?>
    <div class="alert alert-success alert-block" >
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e(session('delete')); ?></strong>
    </div>
<?php endif; ?>


<?php if(Session::has('exception')): ?>
    <div class="alert alert-danger w-100" style="background-color: #f66e84">
        <h6><?php echo e(session('exception')); ?></h6>
    </div>
<?php endif; ?>

<?php if(Session::get('warning')): ?>
    <div class="alert alert-warning alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e(session('warning')); ?></strong>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/website/layouts/messages.blade.php ENDPATH**/ ?>