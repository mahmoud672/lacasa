<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(assetPath('dashboard/css/login/ionicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetPath('dashboard/css/login/index.css')); ?>">
    <title>Login</title>
</head>

<body>
<div class="login-wrapper">
    <div class="logo-div">
        <img src="<?php echo e(assetPath('dashboard/img/logo.png')); ?>" alt="logo">
    </div>
    <form action="<?php echo e(route('login')); ?>" class="login-form" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-div">
            <input type="text" name="email" placeholder="Username" class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-div">
            <input type="password" name="password" placeholder="Password" class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
            <?php endif; ?>
        </div>
        <button type="submit">
            <i class="ion-log-in"></i>
            <span>
          Login
        </span>
        </button>
    </form>
</div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/dashboard/login.blade.php ENDPATH**/ ?>