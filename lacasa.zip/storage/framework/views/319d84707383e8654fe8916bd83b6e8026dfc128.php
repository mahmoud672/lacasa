<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Anything you want
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2020 <a href="#">Company</a>.</strong> All rights reserved.
</footer>
<?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/dashboard/layouts/footer.blade.php ENDPATH**/ ?>