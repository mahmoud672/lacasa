<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>">
<head>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> <?php echo $setting->lang->website_name; ?> -    <?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->yieldContent('open-graph'); ?>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <!-- Fav Icon -->
    <link rel="icon" href="<?php echo e(assetPath("website/images/favicon.png")); ?>" type="image/x-icon">

    <!-- Google Fonts -->


    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@500&display=swap" rel="stylesheet">
    <!-- Stylesheets -->
    <link href="<?php echo e(assetPath("website/css/font-awesome-all.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(assetPath("website/css/icomoon.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(assetPath("website/css/owl.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(assetPath("website/css/bootstrap.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(assetPath("website/css/jquery.fancybox.min.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(assetPath("website/css/animate.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(assetPath("website/css/color.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(assetPath("website/css/global.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(assetPath("website/css/style.css")); ?>" rel="stylesheet">

    <link href="<?php echo e(assetPath("website/css/responsive.css")); ?>" rel="stylesheet">
    <?php if(currentLang() == 'ar'): ?>
        <link href="<?php echo e(assetPath("website/css/rtl.css")); ?>" rel="stylesheet">
    <?php endif; ?>
    <?php echo $__env->yieldContent('canonical'); ?>
    <!-- end canonical links-->

    <!--Define social media profiles with schema.org markup -->

    <?php echo $__env->yieldContent('customizedStyle'); ?>

    <?php echo $__env->yieldContent('header-code'); ?>

</head>


<body id="bg">
<div id="loading-area">

</div>

<!-- Document Wrapper
============================================= -->
<div class="page-wraper">
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>


    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- scroll top button -->
    <button class="scroltop fa fa-arrow-up style5" ></button>

</div>

<!-- jequery plugins -->
<script src="<?php echo e(assetPath("website/js/jquery.js")); ?>"></script>
<script src="<?php echo e(assetPath("website/js/popper.min.js")); ?>"></script>
<script src="<?php echo e(assetPath("website/js/bootstrap.min.js")); ?>"></script>
<script src="<?php echo e(assetPath("website/js/owl.js")); ?>"></script>
<script src="<?php echo e(assetPath("website/js/wow.js")); ?>"></script>
<script src="<?php echo e(assetPath("website/js/validation.js")); ?>"></script>
<script src="<?php echo e(assetPath("website/js/jquery.fancybox.js")); ?>"></script>
<script src="<?php echo e(assetPath("website/js/appear.js")); ?>"></script>
<script src="<?php echo e(assetPath("website/js/scrollbar.js")); ?>"></script>
<script src="<?php echo e(assetPath("website/js/bxslider.js")); ?>"></script>

<!-- main-js -->
<script src="<?php echo e(assetPath("website/js/script.js")); ?>"></script>

<?php echo $__env->yieldContent('customizedScript'); ?>



</body>
</html>
<?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/website/layouts/layouts.blade.php ENDPATH**/ ?>