<?php $__env->startSection('title',  __('trans.contact')); ?>

<?php $__env->startSection('open-graph'); ?>
    <meta name="description" content="<?php echo e($og->description ? $og->description : $mainOpenGraph->description); ?>">
    <meta name="keywords" content="<?php echo e($og->key_words ? $og->key_words : $mainOpenGraph->key_words); ?>">
    <!-- open graph meta-->
    <meta property="og:title"
          content="<?php echo e($og->open_graph->og_title ? $og->open_graph->og_title : $mainOpenGraph->open_graph->og_title); ?>"/>
    <meta property="og:type"
          content="<?php echo e($og->open_graph->og_type ? $og->open_graph->og_type : $mainOpenGraph->open_graph->og_type); ?>"/>
    <meta property="og:url" content="<?php echo e(url('contact')); ?>"/>
    <meta property="og:image" content="
    <?php if($og->open_graph->image_url): ?>
    <?php echo e($og->open_graph->image_url); ?>

    <?php elseif($og->open_graph->open_graph_image): ?>
    <?php echo e(asset($og->open_graph->open_graph_image->path)); ?>

    <?php else: ?>
    <?php echo e($mainOpenGraph->open_graph->image_url); ?>

    <?php endif; ?>
    "
    />
    <meta property="og:description"
          content="<?php echo e($og->open_graph->og_description ? $og->open_graph->og_description : $mainOpenGraph->open_graph->og_description); ?>"/>
    <meta property="og:site_name"
          content="<?php echo e($og->open_graph->og_site_name ? $og->open_graph->og_site_name : $mainOpenGraph->open_graph->og_site_name); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e(url('contact')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-code'); ?>
    <?php echo $headerCode->header_code ? $headerCode->header_code : ''; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customizedScript'); ?>
    <script>
        var currentLocation = location.href;
        $("#came_from").val(currentLocation);
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<!--Page Title-->
<section class="page-title" style="background-image: url(<?php echo e(assetPath("website/images/background/page-title.jpg")); ?>);">
    <div class="auto-container">
        <div class="content-box">
            <div class="title">
                <h1><?php echo e(__("trans.contact")); ?></h1>
            </div>
            <ul class="bread-crumb clearfix">
                <li><a href="<?php echo e(url("/")); ?>"><?php echo e(__("trans.home")); ?></a></li>


                <li class="shape"></li>
                <li><?php echo e(__("trans.contact")); ?></li>
            </ul>
        </div>
    </div>
</section>
<!--End Page Title-->


<!-- contact-style-two -->
<section class="contact-style-two">
    <div class="outer-container">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-6 col-md-12 col-sm-12 form-column">
                    <div class="inner-box">
                        <div class="sec-title light">
                            <p><?php echo e(__("trans.always_contact_with_us")); ?></p>
                            <div class="shape"></div>

                        </div>
                        <div class="form-inner">
                            <?php echo $__env->make("website.layouts.messages", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <form method="post" action="<?php echo e(url("/contact")); ?>" id="contact-form" class="default-form">
                               <?php echo csrf_field(); ?>
                                <input type="hidden" name="came_from" value="" id="came_from">
                                <div class="row clearfix">
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                        <input type="text" name="name" placeholder="<?php echo e(__("trans.form_name")); ?>" value="<?php echo e(old("name")); ?>" required>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                        <input type="email" name="email" placeholder="<?php echo e(__("trans.email")); ?>" value="<?php echo e(old("email")); ?>" required>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="phone" required value="<?php echo e(old("phone")); ?>" placeholder="<?php echo e(__("trans.form_phone")); ?>">
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 form-group">
                                        <input type="text" name="title" required value="<?php echo e(old("title")); ?>" placeholder="<?php echo e(__("trans.message_title")); ?>">
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        <textarea name="message" required placeholder="<?php echo e(__("trans.message")); ?>"><?php echo e(old("message")); ?></textarea>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn">
                                        <button class="theme-btn-one" type="submit" name="submit-form"><?php echo e(__("trans.send")); ?> </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 info-column">
                    <div class="info-box">
                        <h3><?php echo e(__("trans.address_details")); ?></h3>
                        <ul class="info clearfix">
                            <li>
                                <i class="fa fa-map-marker"></i>
                                <p><?php echo e(__("trans.address")); ?></p>
                                <h4>
                                    <?php echo e($contact->address()); ?>

                                </h4>
                            </li>
                            <li>
                                <i class="fa fa-phone"></i>
                                <h4><span><?php echo e(__("trans.phone")); ?></span><a href="tel:<?php echo e($contact->phone); ?>"><?php echo e($contact->phone); ?></a></h4>
                            </li>
                            <li>
                                <i class="fa fa-envelope-open"></i>
                                <h4><span><?php echo e(__("trans.email")); ?></span><a href="mailto:<?php echo e($contact->email); ?>"><?php echo e($contact->email); ?></a></h4>
                            </li>
                        </ul>
                        <ul class="social-links clearfix">
                            <?php if($contact->facebook): ?>
                                <li><a href="<?php echo e($contact->facebook); ?>"><i class="fab fa-facebook-f"></i></a></li>
                            <?php endif; ?>

                            <?php if($contact->twitter): ?>
                                <li><a href="<?php echo e($contact->twitter); ?>"><i class="fab fa-twitter"></i></a></li>
                            <?php endif; ?>

                            <?php if($contact->pinterest): ?>
                                <li><a href="<?php echo e($contact->pinterest); ?>"><i class="fab fa-pinterest-p"></i></a></li>
                            <?php endif; ?>

                            <?php if($contact->google): ?>
                                <li><a href="<?php echo e($contact->google); ?>"><i class="fab fa-google-plus-g"></i></a></li>
                            <?php endif; ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- contact-style-two end -->


<!-- google-map-section -->
<section class="google-map-section">
    <div class="map-inner">
        <iframe src="<?php echo e($contact->location); ?>" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

    </div>
</section>
<!-- google-map-section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/website/contact.blade.php ENDPATH**/ ?>