<!-- main-footer -->
<footer class="main-footer style-two" style="background-image: url(<?php echo e(assetPath("website/images/background/footer-1.jpg")); ?>);">
    <div class="footer-top">
        <div class="auto-container">
            <div class="widget-section">
                <div class="row clearfix">
                    <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                        <div class="footer-widget logo-widget">
                            <div class="footer-logo">
                                <figure class="logo"><a href="<?php echo e(url("/")); ?>"><img src="<?php echo e(assetPath($setting->image_alt->path)); ?>" alt=""></a></figure>
                            </div>
                            <div class="text">
                                <p>
                                    <?php echo e($setting->lang->website_description); ?>

                                </p>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                        <div class="footer-widget links-widget ml-100">
                            <div class="widget-title">
                                <h3><?php echo e(__("trans.quick_links")); ?></h3>
                                <div class="shape"></div>
                            </div>
                            <div class="widget-content">
                                <ul class="links clearfix">
                                    <li><a href="<?php echo e(url("/")); ?>"><?php echo e(__("trans.home")); ?></a></li>
                                    <li><a href="<?php echo e(url("/about")); ?>"><?php echo e(__("trans.about_us")); ?></a></li>
                                    <li><a href="<?php echo e(url("/gallery")); ?>"><?php echo e(__("trans.gallery")); ?></a></li>
                                    <li><a href="<?php echo e(url("/videos")); ?>"><?php echo e(__("trans.videos")); ?></a></li>
                                    <li><a href="<?php echo e(url("/contact")); ?>"><?php echo e(__("trans.contact")); ?></a></li>

                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                        <div class="footer-widget links-widget ml-70">
                            <div class="widget-title">
                                <h3><?php echo e(__("trans.products")); ?></h3>
                                <div class="shape"></div>
                            </div>
                            <div class="widget-content">
                                <ul class="links clearfix">
                                    <?php if($products): ?>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(url("/product/$product->url")); ?>"><?php echo e($product->lang->title); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                        <div class="footer-widget newsletter-widget">
                            <div class="widget-title">
                                <h3><?php echo e(__("trans.contact")); ?></h3>
                                <div class="shape"></div>
                            </div>
                            <ul class="contact-info">
                                <li><span class="icon fa fa-map-marker"></span><?php echo e($contact->address()); ?></li>
                                <li><span class="icon fa fa-phone"></span><?php echo e($contact->phone); ?></li>
                                <li><span class="icon fa fa-phone"></span><?php echo e($contact->phone_alt); ?></li>
                                <li><span class="icon fa fa-envelope-o"></span><?php echo e($contact->email); ?></li>
                            </ul>

                            <ul class="footer-social clearfix">
                                <?php if($contact->facebook): ?>
                                    <li><a href="<?php echo e($contact->facebook); ?>"><i class="fab fa-facebook-f"></i></a></li>
                                <?php endif; ?>

                                <?php if($contact->twitter): ?>
                                    <li><a href="<?php echo e($contact->twitter); ?>"><i class="fab fa-twitter"></i></a></li>
                                <?php endif; ?>

                                <?php if($contact->pinterest): ?>
                                    <li><a href="<?php echo e($contact->pinterest); ?>"><i class="fab fa-pinterest-p"></i></a></li>
                                <?php endif; ?>

                                <?php if($contact->google): ?>
                                    <li><a href="<?php echo e($contact->google); ?>"><i class="fab fa-google-plus-g"></i></a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="auto-container">
            <div class="copyright centred">
                <p>Copyrights © 2021 All Rights Reserved by Be Group</p>
            </div>
        </div>
    </div>
</footer>
<!-- main-footer end -->


<!--Scroll to top-->
<button class="scroll-top scroll-to-target" data-target="html">
    <span class="far fa-long-arrow-alt-up"></span>
</button>
<?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/website/layouts/footer.blade.php ENDPATH**/ ?>