<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('customizedStyle'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customizedScript'); ?>

    <script>
        //Initialize Select2 Elements
        //$('.select2').select2()
        $(function () {
            // Replace the <textarea id="editor1"> with a CKEditor
            // instance, using default configuration.
            CKEDITOR.replace('editor1');
            CKEDITOR.replace('editor2');
            CKEDITOR.replace('editor3');
            CKEDITOR.replace('editor4');
            CKEDITOR.replace('editor5');
            CKEDITOR.replace('editor6');
            CKEDITOR.replace('editor7');
            CKEDITOR.replace('editor8');
            CKEDITOR.replace('editor9');
            CKEDITOR.replace('editor10');
            CKEDITOR.replace('editor11');
            CKEDITOR.replace('editor12');
            //bootstrap WYSIHTML5 - text editor
        });

    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
            About
            <small>Edit About Website</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(adminUrl('/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo e(adminUrl('/about/edit')); ?>">About</a></li>
            <li class="active">Edit About Website</li>
        </ol>
    </section>


    <section class="content">
        <?php echo $__env->make('dashboard.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form role="form" action="<?php echo e(adminUrl('about/update')); ?>" enctype="multipart/form-data" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="row">
                <!-- English Side -->
                <div class="col-md-6">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">Edit About Info</h3>
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                        <div class="box-body">
                            <div class="form-group">

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">About Website</label>
                                    <textarea type="text" class="form-control" name="description_en" id="editor1" placeholder="Enter Mission of Website" rows="5"><?php echo e($about->about_en->description); ?></textarea>
                                    <p class="help-block">Edit Mission of website</p>
                                </div>

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">Mission</label>
                                    <textarea type="text" class="form-control" name="mission_en" id="editor2" rows="6" placeholder="Enter Mission of Website"><?php echo e($about->about_en->mission); ?></textarea>
                                    <p class="help-block">Edit Mission of website</p>
                                </div>


                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">Vision</label>
                                    <textarea type="text" class="form-control" name="vision_en" id="editor3" rows="6" placeholder="Enter Vision of Website" ><?php echo e($about->about_en->vision); ?></textarea>
                                    <p class="help-block">Edit Vision of website</p>
                                </div>

                                

                               

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">Values</label>
                                    <textarea type="text" class="form-control editor1" name="values_en" id="editor4" rows="6" placeholder="Enter Values of Website" ><?php echo e($about->about_en->value); ?></textarea>
                                    <p class="help-block">Edit Values of website</p>
                                </div>

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">BIO</label>
                                    <textarea type="text" class="form-control editor1" name="bio_en" id="editor5" rows="6" placeholder="Enter Values of Website" ><?php echo e($about->about_en->bio); ?></textarea>
                                    <p class="help-block">Edit Values of website</p>
                                </div>

                                

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1"> About Us Image</label>
                                    <input type="file" class="form-control" name="about_image_id" id="exampleInputEmail1" placeholder="Update About Image">
                                    <p class="help-block"> Update The Image in Mission Section</p>
                                </div>

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1"> Mission Image</label>
                                    <input type="file" class="form-control" name="mission_image_id" id="exampleInputEmail1" placeholder="Update Mession Image">
                                    <p class="help-block"> Update The Image in Mission Section</p>
                                </div>

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1"> Vision Image</label>
                                    <input type="file" class="form-control" name="vision_image_id"  id="exampleInputEmail1" placeholder="Update Vision Image">
                                    <p class="help-block"> Update The Image in Vision Section</p>
                                </div>

                               

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1"> Values Image</label>
                                    <input type="file" class="form-control" name="values_image_id" id="exampleInputEmail1" placeholder="Update Values Image">
                                    <p class="help-block"> Update The Image in Values Section</p>
                                </div>

                               

                                

                                

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1"> Video URL</label>
                                    <input type="url" class="form-control" name="video_url" id="exampleInputEmail1" placeholder="Video URL" value="<?php echo e($about->video->url); ?>">
                                    <p class="help-block"> Video URL</p>
                                </div>

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">Bio Video URL</label>
                                    <input type="url" class="form-control" name="bio_video_url" id="exampleInputEmail1" placeholder="Bio Video URL" value="<?php echo e($about->bioVideo->url); ?>">
                                    <p class="help-block">Bio Video URL</p>
                                </div>

                            </div>
                        </div>
                        <div class="box-footer">
                            <div class="col-lg-12">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Arabic Side -->
                <div class="col-md-6 arab_dir">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">أضف بيانات العميل</h3>
                        </div>
                        <!-- .box-header -->
                        <!-- form start -->
                        <div class="box-body">
                            <div class="form-group">

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">عن المركز</label>
                                    <textarea type="text" class="form-control" name="description_ar" id="editor6"placeholder="عن الشركةة" rows="5"><?php echo e($about->about_ar->description); ?></textarea>
                                    <p class="help-block">قم بتعديل معلومات عن الشركة</p>
                                </div>

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">مهمتنا</label>
                                    <textarea type="text" class="form-control" name="mission_ar" id="editor7" rows="6" placeholder="عدل مهمة الشركةة"><?php echo e($about->about_ar->mission); ?></textarea>
                                    <p class="help-block">قم بتعديل مهمة الشركة</p>
                                </div>

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">رؤيتنا</label>
                                    <textarea type="text" class="form-control" name="vision_ar" id="editor8" rows="6" placeholder="عدل رؤية الشركةة" ><?php echo e($about->about_ar->vision); ?></textarea>
                                    <p class="help-block">قم بتعديل رؤية الشركة</p>
                                </div>

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">قيمنا</label>
                                    <textarea type="text" class="form-control" name="values_ar" id="editor9" rows="6" placeholder="عدل قيم الشركة" ><?php echo e($about->about_ar->value); ?></textarea>
                                    <p class="help-block">قم بتعديل قيم الشركة</p>
                                </div>

                                <div class="col-lg-12">
                                    <label for="exampleInputEmail1">السيرة الذاتية</label>
                                    <textarea type="text" class="form-control editor1" name="bio_ar" id="editor10" rows="6" placeholder="أكتب نبذة عن الدكتور" ><?php echo e($about->about_ar->bio); ?></textarea>
                                    <p class="help-block">أكتب نبذة عن الدكتور</p>
                                </div>

                                
                                

                                
                               

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/dashboard/about/edit.blade.php ENDPATH**/ ?>