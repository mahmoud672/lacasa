<?php $__env->startSection('title', __('trans.home')); ?>

<?php $__env->startSection('open-graph'); ?>
        <meta name="description" content="<?php echo e($og->description); ?>">
        <meta name="keywords" content="<?php echo e($og->key_words); ?>">
        <!-- open graph meta-->
        <meta property="og:title" content="<?php echo e($og->open_graph->og_title); ?>"/>
        <meta property="og:type" content="<?php echo e($og->open_graph->og_type); ?>"/>
        <meta property="og:url" content="<?php echo e(url('/')); ?>"/>
        <meta property="og:image" content="<?php echo e($og->open_graph->image_url ? $og->open_graph->image_url : asset($og->open_graph->open_graph_image->path)); ?>"/>
        <meta property="og:description" content="<?php echo e($og->open_graph->og_description); ?>"/>
        <meta property="og:site_name" content="<?php echo e($og->open_graph->og_site_name); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-code'); ?>
    <?php echo $headerCode->header_code ? $headerCode->header_code : ''; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e(url($og->url)); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customizedStyle'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customizedScript'); ?>
    <script>
        var currentLocation = location.href;
        $("#came_from").val(currentLocation);
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- banner-section -->
<section class="banner-section style-two">
    <div class="banner-carousel owl-theme owl-carousel owl-dots-none nav-style-one">
        <?php if($slides): ?>
            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="slide-item">
                    <div class="image-layer" style="background-image:url(<?php echo e(assetPath($slide->image->path)); ?>)"></div>
                    <div class="auto-container">
                    <div class="content-box">
                        <div class="top-text">
                            <div class="shape"></div>

                        </div>
                        <h1><?php echo e($slide->lang->title); ?> <br><?php echo e($slide->lang->sub_title); ?> </h1>
                        <p>تصميمات عصرية تليق بك</p>
                        <?php echo $slide->lang->description; ?>

                        <div class="btn-box">
                            <a href="<?php echo e(url("/about")); ?>" class="theme-btn-one"><?php echo e(__("trans.read_more")); ?></a>
                            <a href="<?php echo e(url("/contact")); ?>" class="banner-btn"><?php echo e(__("trans.contact")); ?></a>
                        </div>
                    </div>
                </div>
        </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</section>
<!-- banner-section end -->


<!-- feature-style-two -->
<section class="feature-style-two bg-color-1">
    <div class="pattern-layer" style="background-image: url(<?php echo e(assetPath("website/images/shape/pattern-2.png")); ?>);"></div>
    <div class="shape-layer">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
        <div class="shape-3"></div>
        <div class="shape-4"></div>
    </div>
    <div class="auto-container">
        <div class="row clearfix">
            <?php if($features): ?>
                <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 feature-block">
                        <div class="feature-block-two">
                            <div class="inner-box">
                                <div class="icon-box"><i class="<?php echo e($feature->lang->slug); ?>"></i></div>
                                <h3><?php echo e($feature->lang->title); ?></h3>
                                
                                <?php echo $feature->lang->description; ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
        </div>
    </div>
</section>
<!-- feature-style-two end -->


<!-- about-style-two -->
<section class="about-style-two">
    <div class="auto-container">
        <div class="upper-box">
            <figure class="vector-image rotate-me"><img src="<?php echo e(assetPath("website/images/resource/vector-image-2.png")); ?>" alt=""></figure>
            <div class="row clearfix">
                <div class="col-lg-6 col-md-12 col-sm-12 title-column">
                    <div class="sec-title">

                        <div class="shape"></div>
                        <h2><?php echo e(__("trans.home_title1")); ?></h2>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 text-column">
                    <div class="text">
                        <?php echo $about->lang->description; ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="lower-box">
            <div class="row clearfix">
                <div class="col-lg-7 col-md-12 col-sm-12 image-column">
                    <div class="image-box">
                        <figure class="image"><img src="<?php echo e(assetPath($about->aboutImage->path)); ?>" alt=""></figure>
                    </div>
                </div>

                <div class="col-lg-5 col-md-12 col-sm-12 content-column">
                    <div class="content-box">
                        <?php if($whyUsFeatures): ?>
                            <?php $__currentLoopData = $whyUsFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-item">
                                    <div class="icon-box"><i class="icon-tick"></i></div>
                                    <h3> <?php echo e($feature->lang->title); ?> </h3>
                                   
                                    <?php echo $feature->lang->description; ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- about-style-two end -->


<!-- service-style-two -->
<section class="service-style-two bg-color-2 centred">
    <div class="pattern-layer" style="background-image: url(<?php echo e(assetPath("website/images/shape/pattern-3.png")); ?>);"></div>
    <div class="auto-container">
        <div class="title-inner">
            <div class="sec-title centred">

                <div class="shape"></div>
                <h2><?php echo e(__("trans.products")); ?></h2>
            </div>


        </div>
        <div class="row clearfix">
            <?php if($products): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 col-sm-12 service-block">
                        <div class="service-block-two mb-80 wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-box">
                                    <i class="icon-icon7"></i>
                                    <a href="<?php echo e(url("/product/$product->url")); ?>">+</a>
                                </div>
                                <div class="lower-content">
                                    <h3><a href="<?php echo e(url("/product/$product->url")); ?>"><?php echo e($product->lang->title); ?></a></h3>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
        
    </div>
</section>
<!-- service-style-two end -->




<!-- working-section -->
<section class="working-section centred">
    <div class="auto-container">
        <div class="sec-title centred">

            <div class="shape"></div>
            <h2><?php echo e(__("trans.services")); ?></h2>
        </div>
        <div class="row clearfix">
            <?php if($mainServices): ?>
                <?php $__currentLoopData = $mainServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 col-sm-12 working-block">
                        <div class="working-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <figure class="image-box"><img src="<?php echo e(assetPath($service->image->path)); ?>" alt=""></figure>
                                <div class="lower-content">
                                    <span class="count-text"><?php echo e($loop->iteration); ?></span>
                                    <div class="inner">
                                        <h3><a href="<?php echo e(url("/service/$service->url")); ?>"><?php echo e($service->lang->title); ?></a></h3>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
    </div>
</section>
<!-- working-section end -->


<!-- project-section -->
<section class="project-section">
    <div class="outer-container clearfix">
        <?php if($galleryImages): ?>
            <?php $__currentLoopData = $galleryImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-column">
                    <div class="project-block-one">
                        <div class="inner-box">
                            <figure class="image-box">
                                <img src="<?php echo e(assetPath($image->image->path)); ?>" alt="">
                            </figure>
                            <div class="content-box">
                                <div class="view-btn"><a href="<?php echo e(assetPath($image->image->path)); ?>" class="lightbox-image" data-fancybox="gallery">+</a></div>


                            </div>
                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
       
    </div>
</section>
<!-- project-section end -->




<!-- clients-section -->
<section class="clients-section bg-color-2">
    <div class="auto-container">
        <div class="auto-container">
            <div class="clients-carousel owl-carousel owl-theme owl-nav-none owl-dots-none">
                <?php if($clients): ?>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <figure class="clients-logo-box"><a href="<?php echo e(url("/")); ?>"><img src="<?php echo e(assetPath($client->image->path)); ?>" alt=""></a></figure>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>
<!-- clients-section end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/website/welcome.blade.php ENDPATH**/ ?>