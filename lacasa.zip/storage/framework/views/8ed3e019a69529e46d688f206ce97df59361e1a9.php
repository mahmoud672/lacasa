<?php $__env->startSection('title', $product->{'product_'.currentLang()}->title); ?>

<?php $__env->startSection('open-graph'); ?>
    <meta name="description" content="<?php echo e($og->description ? $og->description : $mainOpenGraph->description); ?>">
    <meta name="keywords" content="<?php echo e($og->key_words ? $og->key_words : $mainOpenGraph->key_words); ?>">
    <!-- open graph meta-->
    <meta property="og:title" content="<?php echo e($og->open_graph->og_title ? $og->open_graph->og_title : $mainOpenGraph->open_graph->og_title); ?>"/>
    <meta property="og:type" content="<?php echo e($og->open_graph->og_type ? $og->open_graph->og_type : $mainOpenGraph->open_graph->og_type); ?>"/>
    <meta property="og:url" content="<?php echo e(url('/product')); ?>"/>
    <meta property="og:image" content="
    <?php if($og->open_graph->image_url): ?>
    <?php echo e($og->open_graph->image_url); ?>

    <?php elseif($og->open_graph->open_graph_image): ?>
    <?php echo e(asset($og->open_graph->open_graph_image->path)); ?>

    <?php else: ?>
    <?php echo e($mainOpenGraph->open_graph->image_url); ?>

    <?php endif; ?>
    "
    />
    <meta property="og:description" content="<?php echo e($og->open_graph->og_description ? $og->open_graph->og_description : $mainOpenGraph->open_graph->og_description); ?>"/>
    <meta property="og:site_name" content="<?php echo e($og->open_graph->og_site_name ? $og->open_graph->og_site_name : $mainOpenGraph->open_graph->og_site_name); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e(url('contact')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-code'); ?>
    <?php echo $headerCode->header_code ? $headerCode->header_code : ''; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customizedScript'); ?>
    <script>
        var currentLocation = location.href;
        $("#came_from").val(currentLocation);
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<!--Page Title-->
<section class="page-title" style="background-image: url(<?php echo e(assetPath("website/images/background/page-title.jpg")); ?>);">
    <div class="auto-container">
        <div class="content-box">
            <div class="title">
                <h1><?php echo e($product->lang->title); ?></h1>
            </div>
            <ul class="bread-crumb clearfix">
                <li><a href="<?php echo e(url("/")); ?>"><?php echo e(__("trans.home")); ?></a></li>


                <li class="shape"></li>
                <li><?php echo e(__("trans.products")); ?></li>

                <li class="shape"></li>
                <li><?php echo e($product->lang->title); ?></li>
            </ul>
        </div>
    </div>
</section>
<!--End Page Title-->


<!-- service-details -->
<section class="service-details">
    <div class="auto-container">
        <div class="row clearfix">
            <div class="col-lg-4 col-md-12 col-sm-12 sidebar-side">
                <div class="service-sidebar default-sidebar mr-20">
                    <div class="sidebar-widget category-widget">
                        <div class="widget-title">
                            <h3><?php echo e(__("trans.more")); ?></h3>
                            <div class="shape"></div>
                        </div>
                        <div class="widget-content">
                            <ul class="category-list clearfix">
                                <?php if($anotherProducts): ?>
                                    <?php $__currentLoopData = $anotherProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anotherProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li <?php echo e(request()->is(url("/product/$anotherProduct->url") == url("/product/$anotherProduct->url"))); ?>>
                                            <h5><a href="<?php echo e(url("/product/$anotherProduct->url")); ?>"><?php echo e($anotherProduct->lang->title); ?> </a></h5>
                                            <span class="line"></span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>




                    <div class="sidebar-widget free-quote">
                        <div class="widget-title">
                            <h3><?php echo e(__("trans.contact")); ?></h3>
                            <div class="shape"></div>
                        </div>
                        <?php echo $__env->make("website.layouts.messages", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="widget-content">
                            <form action="<?php echo e(url("/contact")); ?>" method="post" class="quote-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="came_from" value="" id="came_from">
                                <div class="form-group">
                                    <input type="text" name="name" placeholder="<?php echo e(__("trans.form_name")); ?>" required value="<?php echo e(old("name")); ?>">
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" placeholder="<?php echo e(__("trans.email")); ?>" required value="<?php echo e(old("email")); ?>">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="phone" placeholder="<?php echo e(__("trans.phone")); ?>" required value="<?php echo e(old("phone")); ?>">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="title" placeholder="<?php echo e(__("trans.message_title")); ?>"  value="<?php echo e(old("title")); ?>">
                                </div>
                                <div class="form-group">
                                    <textarea name="message" placeholder="<?php echo e(__("trans.message")); ?>"><?php echo e(old("message")); ?></textarea>
                                </div>
                                <div class="form-group message-btn">
                                    <button type="submit" class="theme-btn-one"><?php echo e(__("trans.send")); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-md-12 col-sm-12 content-side">
                <div class="service-details-content">
                    <div class="content-one">
                        <figure class="image-box"><img src="<?php echo e(assetPath($product->image->path)); ?>" alt=""></figure>
                        <div class="text">
                            <h2><?php echo e($product->lang->title); ?></h2>
                            <?php echo $product->lang->description; ?>





                        </div>
                    </div>
                    <div class="two-column">
                        <div class="row clearfix">
                            <div class="col-lg-12 col-md-6 col-sm-12 video-column">
                                <div class="video-inner" style="background-image: url(<?php echo e(assetPath("website/images/resource/video-1.jpg")); ?>);">
                                    <div class="video-content centred">
                                        <a href="<?php echo e($product->video->url); ?>" class="lightbox-image video-btn" data-caption=""><i class="far fa-play"></i></a>

                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</section>
<!-- service-details end -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('website.layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/website/product-details.blade.php ENDPATH**/ ?>