<?php $__env->startSection('title', __('trans.about_us')); ?>

<?php $__env->startSection('open-graph'); ?>
    <meta name="description" content="<?php echo e($og->description ? $og->description : $mainOpenGraph->description); ?>">
    <meta name="keywords" content="<?php echo e($og->key_words ? $og->key_words : $mainOpenGraph->key_words); ?>">
    <!-- open graph meta-->
    <meta property="og:title"
          content="<?php echo e($og->open_graph->og_title ? $og->open_graph->og_title : $mainOpenGraph->open_graph->og_title); ?>"/>
    <meta property="og:type"
          content="<?php echo e($og->open_graph->og_type ? $og->open_graph->og_type : $mainOpenGraph->open_graph->og_type); ?>"/>
    <meta property="og:url" content="<?php echo e(url('/about')); ?>"/>
    <meta property="og:image" content="
    <?php if($og->open_graph->image_url): ?>
    <?php echo e($og->open_graph->image_url); ?>

    <?php elseif($og->open_graph->open_graph_image): ?>
    <?php echo e(asset($og->open_graph->open_graph_image->path)); ?>

    <?php else: ?>
    <?php echo e($mainOpenGraph->open_graph->image_url); ?>

    <?php endif; ?>
    "
    />
    <meta property="og:description"
          content="<?php echo e($og->open_graph->og_description ? $og->open_graph->og_description : $mainOpenGraph->open_graph->og_description); ?>"/>
    <meta property="og:site_name"
          content="<?php echo e($og->open_graph->og_site_name ? $og->open_graph->og_site_name : $mainOpenGraph->open_graph->og_site_name); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    <link rel="canonical" href="<?php echo e(url($og->url)); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-code'); ?>
    <?php echo $headerCode->header_code ? $headerCode->header_code : ''; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customizedScript'); ?>
    <script>
        var currentLocation = location.href;
        $("#came_from").val(currentLocation);


        $(".main-section-ul ul").addClass("about-dropped")
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   <!--Page Title-->
   <section class="page-title" style="background-image: url(<?php echo e(assetPath("website/images/background/page-title.jpg")); ?>);">
       <div class="auto-container">
           <div class="content-box">
               <div class="title">
                   <h1><?php echo e(__("trans.about_us")); ?></h1>
               </div>
               <ul class="bread-crumb clearfix">
                   <li><a href="<?php echo e(url("/")); ?>"><?php echo e(__("trans.home")); ?></a></li>
                   <li class="shape"></li>
                   <li><?php echo e(__("trans.about_us")); ?></li>
               </ul>
           </div>
       </div>
   </section>
   <!--End Page Title-->


   <!-- about-section -->
   <section class="about-section">
       <div class="auto-container">
           <div class="row clearfix">
               <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                   <div class="content_block_1">
                       <div class="content-box">
                           <div class="sec-title">

                               <div class="shape"></div>
                               <h2><?php echo e(__("trans.about_us")); ?></h2>
                           </div>
                           <div class="text">
                              <?php echo $about->lang->description; ?>

                           </div>
                           <div class="inner-box">
                               <figure class="vector-image"><img src="<?php echo e(assetPath("website/images/resource/vector-image-1.png")); ?>" alt=""></figure>
                               <div class="inner clearfix">
                                   <?php if($why_us): ?>
                                       <ul class="list-item">
                                           <?php $__currentLoopData = $why_us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <li><?php echo e($feature->lang->title); ?></li>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </ul>
                                   <?php endif; ?>

                                  
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                   <div class="image_block_1">
                       <div class="image-box ml-55">
                           <figure class="vector-image rotate-me"><img src="<?php echo e(assetPath("website/images/resource/vector-image-2.png")); ?>" alt=""></figure>
                           <div class="image-pattern">
                               <div class="pattern-1"></div>
                               <div class="pattern-2"></div>
                               <div class="pattern-3"></div>
                               <div class="pattern-4"></div>
                           </div>
                           <figure class="image"><img src="<?php echo e(assetPath($about->aboutImage->path)); ?>" alt=""></figure>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </section>
   <!-- about-section end -->


   <!-- history-section -->
   <section class="history-section">
       <div class="auto-container">
           <div class="sec-title centred">

               <div class="shape"></div>
               <h2></h2>
           </div>
           <div class="tabs-box">
               <div class="tab-btn-box">
                   <ul class="tab-btns tab-buttons centred clearfix">
                       <li class="tab-btn" data-tab="#tab-1"><?php echo e(__("trans.mission")); ?></li>
                       <li class="tab-btn active-btn" data-tab="#tab-2"><?php echo e(__("trans.vision")); ?></li>
                       <li class="tab-btn" data-tab="#tab-3"><?php echo e(__("trans.values")); ?></li>

                   </ul>
               </div>
               <div class="tabs-content">
                   <div class="tab" id="tab-1">
                       <div class="row clearfix align-items-center">
                           <div class="col-lg-6 col-md-6 col-sm-12 image-column">
                               <div class="image-box">
                                   <figure class="image"><img src="<?php echo e(assetPath($about->missionImage->path)); ?>" alt=""></figure>
                               </div>
                           </div>
                           <div class="col-lg-6 col-md-6 col-sm-12 content-column">
                               <div class="content_block_3">
                                   <div class="content-box">
                                       <h2><?php echo e(__("trans.mission")); ?></h2>

                                       <?php echo $about->lang->mission; ?>



                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="tab active-tab" id="tab-2">
                       <div class="row clearfix align-items-center">
                           <div class="col-lg-6 col-md-6 col-sm-12 image-column">
                               <div class="image-box">
                                   <figure class="image"><img src="<?php echo e(assetPath($about->visionImage->path)); ?>" alt=""></figure>
                               </div>
                           </div>
                           <div class="col-lg-6 col-md-6 col-sm-12 content-column">
                               <div class="content_block_3">
                                   <div class="content-box">
                                       <h2><?php echo e(__("trans.vision")); ?></h2>
                                       <?php echo $about->lang->vision; ?>


                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="tab" id="tab-3">
                       <div class="row clearfix align-items-center">
                           <div class="col-lg-6 col-md-6 col-sm-12 image-column">
                               <div class="image-box">
                                   <figure class="image"><img src="<?php echo e(assetPath($about->valuesImage->path)); ?>" alt=""></figure>
                               </div>
                           </div>
                           <div class="col-lg-6 col-md-6 col-sm-12 content-column">
                               <div class="content_block_3">
                                   <div class="content-box">
                                       <h2><?php echo e(__("trans.values")); ?></h2>
                                       <?php echo $about->lang->value; ?>


                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>

               </div>
           </div>
       </div>
   </section>
   <!-- history-section end -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/website/about.blade.php ENDPATH**/ ?>