<?php $__env->startSection('title', __('trans.gallery')); ?>

<?php $__env->startSection('open-graph'); ?>
    <meta name="description" content="<?php echo e($og->description ? $og->description : $mainOpenGraph->description); ?>">
    <meta name="keywords" content="<?php echo e($og->key_words ? $og->key_words : $mainOpenGraph->key_words); ?>">
    <!-- open graph meta-->
    <meta property="og:title" content="<?php echo e($og->open_graph->og_title ? $og->open_graph->og_title : $mainOpenGraph->open_graph->og_title); ?>"/>
    <meta property="og:type" content="<?php echo e($og->open_graph->og_type ? $og->open_graph->og_type : $mainOpenGraph->open_graph->og_type); ?>"/>
    
    <meta property="og:image" content="
    <?php if($og->open_graph->image_url): ?>
    <?php echo e($og->open_graph->image_url); ?>

    <?php elseif($og->open_graph->open_graph_image): ?>
    <?php echo e(asset($og->open_graph->open_graph_image->path)); ?>

    <?php else: ?>
    <?php echo e($mainOpenGraph->open_graph->image_url); ?>

    <?php endif; ?>
    "
    />
    <meta property="og:description" content="<?php echo e($og->open_graph->og_description ? $og->open_graph->og_description : $mainOpenGraph->open_graph->og_description); ?>"/>
    <meta property="og:site_name" content="<?php echo e($og->open_graph->og_site_name ? $og->open_graph->og_site_name : $mainOpenGraph->open_graph->og_site_name); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('canonical'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-code'); ?>
    <?php echo $headerCode->header_code ? $headerCode->header_code : ''; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customizedScript'); ?>
    <script>
        var currentLocation = location.href;
        $("#came_from").val(currentLocation);
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!--Page Title-->
<section class="page-title" style="background-image: url(<?php echo e(assetPath("website/images/background/page-title.jpg")); ?>);">
    <div class="auto-container">
        <div class="content-box">
            <div class="title">
                <h1><?php echo e(__("trans.gallery")); ?></h1>
            </div>
            <ul class="bread-crumb clearfix">
                <li><a href="<?php echo e(url("/")); ?>"><?php echo e(__("trans.home")); ?></a></li>
                <li class="shape"></li>
                <li><?php echo e(__("trans.gallery")); ?></li>
            </ul>
        </div>
    </div>
</section>
<!--End Page Title-->


<!-- gallery-page-section -->
<section class="gallery-page-section sec-pad-2">
    <div class="auto-container">
        <div class="sortable-masonry">


            <div class="items-container row clearfix">
                <?php if($images): ?>
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-6 col-sm-12 masonry-item small-column all shutters curtains blinds home_drcor">
                            <div class="project-block-one">
                                <div class="inner-box">
                                    <figure class="image-box">
                                        <img src="<?php echo e(assetPath($image->image->path)); ?>" alt="">
                                    </figure>
                                    <div class="content-box">
                                        <div class="view-btn"><a href="<?php echo e(assetPath($image->image->path)); ?>" class="lightbox-image" data-fancybox="gallery">+</a></div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>

        </div>
    </div>
</section>
<!-- gallery-page-section end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/website/gallery.blade.php ENDPATH**/ ?>