
<!-- main header -->
<header class="main-header style-two">
    <!-- header-top -->
    <div class="header-top">
        <div class="auto-container">
            <div class="top-inner clearfix">
                <ul class="info clearfix pull-right">
                    <li><a href="<?php echo e(currentLang() == 'en' ? url("/lang/ar") : url("/lang/en")); ?>"><?php echo e(currentLang() == 'en' ? "Arabic" : "English"); ?></a></li>


                </ul>
                <ul class="header-social clearfix pull-left">
                    <?php if($contact->facebook): ?>
                        <li><a href="<?php echo e($contact->facebook); ?>"><i class="fab fa-facebook-f"></i></a></li>
                    <?php endif; ?>

                    <?php if($contact->twitter): ?>
                        <li><a href="<?php echo e($contact->twitter); ?>"><i class="fab fa-twitter"></i></a></li>
                    <?php endif; ?>

                    <?php if($contact->pinterest): ?>
                        <li><a href="<?php echo e($contact->pinterest); ?>"><i class="fab fa-pinterest-p"></i></a></li>
                    <?php endif; ?>

                    <?php if($contact->google): ?>
                        <li><a href="<?php echo e($contact->google); ?>"><i class="fab fa-google-plus-g"></i></a></li>
                    <?php endif; ?>

                </ul>
            </div>
        </div>
    </div>
    <!-- header-upper -->
    <div class="header-upper">
        <div class="pattern-layer" style="background-image: url(<?php echo e(assetPath("website/images/shape/pattern-2.png")); ?>);"></div>
        <div class="auto-container">
            <div class="upper-inner clearfix">
                <div class="logo-box pull-right">
                    <figure class="logo"><a href="<?php echo e(url("/")); ?>"><img src="<?php echo e(assetPath($setting->image->path)); ?>" alt=""></a></figure>
                </div>
                <ul class="upper-info clearfix pull-left">
                    <li>
                        <i class="fas fa-map-marker-alt"></i>
                        <h6><?php echo e(__("trans.address")); ?></h6>
                        <h5><?php echo e($contact->address()); ?></h5>
                    </li>
                    <li>
                        <i class="fas fa-phone-volume"></i>
                        <h6><?php echo e(__("trans.phone")); ?></h6>
                        <h5><a href="tel:<?php echo e($contact->phone); ?>"><?php echo e($contact->phone); ?></a></h5>
                    </li>
                    <li>
                        <i class="fab fa-whatsapp"></i>
                        <h6><?php echo e(__("trans.whatsapp")); ?></h6>
                        <h5><a href="tel:<?php echo e($contact->whatsapp); ?>"><?php echo e($contact->whatsapp); ?></a></h5>
                    </li>


                </ul>
            </div>
        </div>
    </div>
    <!-- header-lower -->
    <div class="header-lower">
        <div class="auto-container">
            <div class="lower-inner">
                <div class="outer-box clearfix">
                    <div class="menu-area pull-right">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler">
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                            <i class="icon-bar"></i>
                        </div>
                        <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">

                                    <li class="<?php echo e(request()->is("/") ? "current" : ""); ?>"><a href="<?php echo e(url("/")); ?>"><?php echo e(__("trans.home")); ?></a></li>
                                    <li class="<?php echo e(request()->is("about") ? "current" : ""); ?>"><a href="<?php echo e(url("/about")); ?>"><?php echo e(__("trans.about_us")); ?></a></li>

                                    <li class="dropdown"><a href="#"><?php echo e(__("trans.products")); ?></a>
                                        <ul>
                                            <?php if($products): ?>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(url("/product/$product->url")); ?>"><?php echo e($product->lang->title); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#"><?php echo e(__("trans.services")); ?></a>
                                        <ul>
                                            <?php if($mainServices): ?>
                                                <?php $__currentLoopData = $mainServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(url("/service/$service->url")); ?>"><?php echo e($service->lang->title); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                        </ul>
                                    </li>
                                    <li class="<?php echo e(request()->is("gallery") ? "current" : ""); ?>" ><a href="<?php echo e(url("/gallery")); ?>"><?php echo e(__("trans.gallery")); ?></a></li>



                                    <li class="<?php echo e(request()->is("contact") ? "current" : ""); ?>"><a href="<?php echo e(url("/contact")); ?>"><?php echo e(__("trans.contact")); ?></a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    <ul class="menu-right-content pull-left clearfix">


                        <li class="support-box ">
                            <a href="<?php echo e(url("/contact")); ?>">
                                <i class="icon-calendar"></i>
                                <h4><?php echo e(__("trans.contact")); ?></h4>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!--sticky Header-->
    <div class="sticky-header">
        <div class="auto-container">
            <div class="outer-box clearfix">
                <div class="menu-area pull-right
                           ">
                    <nav class="main-menu clearfix">
                        <!--Keep This Empty / Menu will come through Javascript-->
                    </nav>
                </div>
                <ul class="menu-right-content pull-left clearfix">


                    <li class="support-box">
                        <a href="<?php echo e(url("/")); ?>">
                            <i class="icon-calendar"></i>
                            <h4><?php echo e(__("trans.contact")); ?></h4>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</header>
<!-- main-header end -->

<!-- Mobile Menu  -->
<div class="mobile-menu">
    <div class="menu-backdrop"></div>
    <div class="close-btn"><i class="fas fa-times"></i></div>

    <nav class="menu-box">
        <div class="nav-logo"><a href="<?php echo e(url("/")); ?>"><img src="<?php echo e(assetPath($setting->image->path)); ?>" alt="" title=""></a></div>
        <div class="menu-outer"></div>


        <div class="social-links">
            <ul class="clearfix">
                <?php if($contact->facebook): ?>
                    <li><a href="<?php echo e($contact->facebook); ?>"><i class="fab fa-facebook-square"></i></a></li>
                <?php endif; ?>

                <?php if($contact->twitter): ?>
                    <li><a href="<?php echo e($contact->twitter); ?>"><i class="fab fa-twitter"></i></a></li>
                <?php endif; ?>

                <?php if($contact->pinterest): ?>
                    <li><a href="<?php echo e($contact->pinterest); ?>"><i class="fab fa-pinterest-p"></i></a></li>
                <?php endif; ?>

                <?php if($contact->google): ?>
                    <li><a href="<?php echo e($contact->google); ?>"><i class="fab fa-google-plus-g"></i></a></li>
                <?php endif; ?>

            </ul>
        </div>
    </nav>
</div><!-- End Mobile Menu -->

<?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/website/layouts/header.blade.php ENDPATH**/ ?>