<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(assetPath(setting()->image->path)); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(Auth::user()->name); ?> </p>
                <!-- Status -->
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <!-- search form (Optional) -->
        
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">HEADER</li>
            <!-- Optionally, you can add icons to the links -->
            <li class="active"><a href="<?php echo e(adminUrl('/')); ?>"><i class="fa fa-dashboard"></i> <span>Statistics</span></a></li>

            

            

            

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-shopping-basket"></i>
                    <span>Products</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(adminUrl('product/create')); ?>"><i class="fa fa-plus"></i> Add Product</a></li>
                    <li><a href="<?php echo e(adminUrl('product')); ?>"><i class="fa fa-edit"></i> Show / Edit Product</a></li>
                </ul>
            </li>


            
            
            

            
            
            

            

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-file-image-o"></i>
                    <span>Gallery</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(adminUrl('gallery/create')); ?>"><i class="fa fa-upload"></i> Upload To Gallery</a></li>
                    <li><a href="<?php echo e(adminUrl('gallery')); ?>"><i class="fa fa-edit"></i> Show / Edit Gallery</a></li>
                </ul>
            </li>

           

            
            

            <li class="treeview">
               <a href="#">
                   <i class="fa fa-file-image-o"></i>
                   <span>Clients</span>
                   <i class="fa fa-angle-left pull-right"></i>
               </a>
               <ul class="treeview-menu">
                   <li><a href="<?php echo e(adminUrl('gallery/create?type=clients')); ?>"><i class="fa fa-upload"></i> Upload To Clients</a></li>
                   <li><a href="<?php echo e(adminUrl('gallery?type=clients')); ?>"><i class="fa fa-edit"></i> Show / Edit Clients</a></li>
               </ul>
           </li>
          

            
           

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-pie-chart"></i>
                    <span>SEO</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-desktop"></i>
                            <span>Open Graph</span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="<?php echo e(adminUrl("seo/open-graph?type=main")); ?>"><i class="fa fa-bar-chart"></i>Main Pages Open Graph</a></li>
                             <!---<li><a href="<?php echo e(adminUrl("seo/open-graph?type=blog")); ?>"><i class="fa fa-newspaper-o"></i>Blog Open Graph</a></li>--->
                            <!--<li><a href="<?php echo e(adminUrl("seo/open-graph?type=album")); ?>"><i class="fa fa-file-image-o"></i>Album Open Graph</a></li>-->
                        <!--<li><a href="<?php echo e(adminUrl("seo/open-graph?type=product")); ?>"><i class="fa fa-product-hunt"></i>Product Open Graph</a></li>-->
                        <!--<li><a href="<?php echo e(adminUrl("seo/open-graph?type=category")); ?>"><i class="fa fa-product-hunt"></i>Category Open Graph</a></li>-->
                        </ul>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-desktop"></i>
                            <span>Website Pages</span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="<?php echo e(adminUrl("seo/website-pages?type=main")); ?>"><i class="fa fa-bar-chart"></i>Main Pages</a></li>
                        <!--<li><a href="<?php echo e(adminUrl("seo/website-pages?type=blog")); ?>"><i class="fa fa-newspaper-o"></i>Blog Pages</a></li>-->
                        <!--<li><a href="<?php echo e(adminUrl("seo/website-pages?type=album")); ?>"><i class="fa fa-file-image-o"></i>Album Pages</a></li>-->
                        <!--<li><a href="<?php echo e(adminUrl("seo/website-pages?type=product")); ?>"><i class="fa fa-product-hunt"></i>Product Pages</a></li>-->
                        <!--<li><a href="<?php echo e(adminUrl("seo/website-pages?type=category")); ?>"><i class="fa fa-product-hunt"></i>Category Pages</a></li>-->
                        </ul>
                    </li>
                </ul>
            </li>

            

            

           

            

            

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-list-ol"></i>
                    <span>Features</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(adminUrl('feature/create')); ?>"><i class="fa fa-edit"></i> Add Feature</a></li>
                    <li><a href="<?php echo e(adminUrl('feature')); ?>"><i class="fa fa-plus"></i> Show / Edit Features</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-list-alt"></i>
                    <span>Why Us</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(adminUrl('feature/create?type=why-us')); ?>"><i class="fa fa-edit"></i> Add Feature</a></li>
                    <li><a href="<?php echo e(adminUrl('feature?type=why-us')); ?>"><i class="fa fa-plus"></i> Show / Edit Features</a></li>
                </ul>
            </li>

            

            

            

            

            

            

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-image"></i>
                    <span>Slider</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(adminUrl('slider/create')); ?>"><i class="fa fa-plus"></i> Add Slider</a></li>
                    <li><a href="<?php echo e(adminUrl('slider')); ?>"><i class="fa fa-edit"></i> Show / Edit Slide</a></li>
                </ul>
            </li>

           


            



            <li class="treeview">
                <a href="#">
                    <i class="fa fa-envelope"></i>
                    <span>Messages</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(adminUrl('message')); ?>"><i class="fa fa-edit"></i> Show Inbox</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-globe"></i>
                    <span>About</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(adminUrl('about/edit')); ?>"><i class="fa fa-edit"></i> Edit About Website</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-globe"></i>
                    <span>Services</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(adminUrl('service/create')); ?>"><i class="fa fa-plus"></i> Create Service</a></li>
                    <li><a href="<?php echo e(adminUrl('service')); ?>"><i class="fa fa-edit"></i> Edit Services</a></li>
                </ul>
            </li>

           


            <li class="treeview">
                <a href="#">
                    <i class="fa fa-phone"></i>
                    <span>Contact</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(adminUrl('contact/edit')); ?>"><i class="fa fa-edit"></i> Edit Contact Info</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-cogs"></i>
                    <span>Setting</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo e(adminUrl('setting/edit')); ?>"><i class="fa fa-edit"></i> Edit Website Setting</a></li>
                </ul>
            </li>
        </ul>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\xampp\htdocs\projects\AFW\lacasa\resources\views/dashboard/layouts/sideMenu.blade.php ENDPATH**/ ?>